<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <main class="main-content pos-app w-full px-[var(--margin-x)] pb-6 transition-all duration-[.25s]">
        <div class="mt-3 col-12 container">

            <div class="col-span-12 sm:col-span-6 lg:col-span-8">


                <?php if($errors->any()): ?>
                    <div class="space-y-4 mt-5">
                        <div x-data="{ isShow: true }" :class="!isShow && 'opacity-0 transition-opacity duration-300'"
                            class="alert flex items-center justify-between overflow-hidden rounded-lg border border-warning text-info">
                            <div class="flex">
                                <div class="bg-warning p-3 text-white">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none"
                                        viewbox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                    </svg>
                                </div>
                                <div class="px-4 py-3 sm:px-5 text-warning"><?php echo e($errors->first()); ?></div>
                            </div>
                            <div class="px-2">
                                <button @click="isShow = false; setTimeout(()=>$root.remove(),300)"
                                    class="btn h-7 w-7 rounded-full p-0 font-medium text-warning hover:bg-warning/20 focus:bg-warning/20 active:bg-warning/25">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none"
                                        viewbox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M6 18L18 6M6 6l12 12" />
                                    </svg>
                                </button>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>


                <div style="margin-top: 15px;margin-bottom: 15px;" class="swiper" x-init="$nextTick(() => $el._x_swiper = new Swiper($el, { slidesPerView: 'auto', spaceBetween: 14, navigation: { nextEl: '.next-btn', prevEl: '.prev-btn' } }))">
                    <div class="flex items-center justify-between">
                        <p class="text-base font-medium text-slate-700 dark:text-navy-100">
                            <i class="fa-brands fa-google-wallet mr-1"></i>
                            Cashout
                        </p>
                    </div>
                </div>

                <div class="api-offers api_of_grid rew_add">

                    <?php $__currentLoopData = $redeemlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reward): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="flex flex-col" style="position: relative;"
                            <?php if($u_po >= $reward->points): ?>
                            href="<?php echo e(route('cashout_', $reward->txn_id)); ?>"
                            <?php else: ?>
                            <?php if(empty(Auth::user())): ?>
                            href="<?php echo e(route('login')); ?>"
                            <?php else: ?>
                            @click="$notification({text:'You do not have enough <?php echo e(num($reward->points)); ?> points',variant:'error',position:'center-bottom'})"
                            <?php endif; ?>
                            <?php endif; ?>>
                            <i class="rewtag"><?php echo e($reward->price); ?></i>
                            <img class="h-44 w-full rounded-2xl object-cover object-center rew_img"
                                src="<?php echo e(url('images/app/' . $reward->image . '')); ?>">
                            <div class="card -mt-8 grow rounded-2xl p-4 rew_title">
                                <div class="rew_flex">
                                    <div class="font-medium text-slate-700 line-clamp-1 dark:text-navy-100">
                                        <?php echo e($reward->title); ?></div>

                                    <div class="off_sp_btn flex items-center gap-1"
                                        style="background:<?php echo e($reward->color); ?>;">
                                        <img style="height: 12px;" src="/images/app/app-coin.png">
                                        <span><?php echo e(num($reward->points)); ?></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>



            </div>

        </div>
    </main>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php /**PATH /home/u442681501/domains/csmdevelopers.com/public_html/offercash_website/project/resources/views/reward.blade.php ENDPATH**/ ?>