
<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <main class="main-content w-full px-[var(--margin-x)] pb-8">
        <div class="flex items-center space-x-4 py-5 lg:py-6">
            <h2 class="text-xl font-medium text-slate-800 dark:text-navy-50 lg:text-2xl">
              Admin
            </h2>
            <div class="hidden h-full py-1 sm:flex">
              <div class="h-full w-px bg-slate-300 dark:bg-navy-600"></div>
            </div>
            <ul class="hidden flex-wrap items-center space-x-2 sm:flex">
              <li class="flex items-center space-x-2">
                <a class="text-white transition-colors hover:text-primary-focus dark:text-accent-light dark:hover:text-accent" href="<?php echo e(route('admin.dashboard')); ?>">
                Home</a>
                <svg x-ignore="" xmlns="http://www.w3.org/2000/svg" class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
                </svg>
              </li>
              <li>Tracker</li>
            </ul>
          </div>

          <?php if(session('status-alert')): ?>
          <div class="alert flex rounded-lg bg-error px-4 py-4 text-white sm:px-5 sess_msg">
          <?php echo e(session('status-alert')); ?>

          </div>
          <?php elseif(session('status-success')): ?>
          <div class="alert flex rounded-lg bg-success px-4 py-4 text-white sm:px-5 mb-3 sess_msg">
            <?php echo e(session('status-success')); ?>

          </div>
          <?php else: ?>

          <?php endif; ?>

          <div>


            <div class="col-span-12">
                <div class="flex items-center justify-between">
                  <h2 class="text-base font-medium tracking-wide text-slate-700 line-clamp-1 dark:text-navy-100">

                  </h2>
                <div class="flex" style="gap:8px;">

            </div>
           </div>

           <div class="card is-scrollbar-hidden min-w-full overflow-x-auto mt-3">
            <table class="is-zebra w-full text-left">
              <thead>
                <tr>
                  <th
                    class="whitespace-nowrap rounded-l-lg bg-slate-200 px-3 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5"
                  >
                    #
                  </th>
                  <th
                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5"
                  >
                    Name
                  </th>
                  <th
                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5"
                  >
                    Activity
                  </th>
                  <th
                    class="whitespace-nowrap bg-slate-200 px-4 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5"
                  >
                    points
                  </th>
                  <th
                    class="whitespace-nowrap rounded-r-lg bg-slate-200 px-3 py-3 font-semibold uppercase text-slate-800 dark:bg-navy-800 dark:text-navy-100 lg:px-5"
                  >
                    date
                  </th>
                </tr>
              </thead>
              <tbody>
                <?php $count = 0; ?>
                <?php $__empty_1 = true; $__currentLoopData = $user_track; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $count++; ?>
                <tr>
                  <td class="whitespace-nowrap rounded-l-lg px-4 py-3 sm:px-5"><?php echo e($count); ?></td>
                  <td class="whitespace-nowrap px-4 py-3 sm:px-5"><?php echo e($user->name); ?></td>
                  <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                    <?php echo e($user->type); ?>

                  </td>
                  <td class="whitespace-nowrap px-4 py-3 sm:px-5">
                    <p class="font-semibold text-success"><?php echo e($user->transation); ?></p>
                  </td>
                  <td class="whitespace-nowrap rounded-r-lg px-4 py-3 sm:px-5">
                  <?php if($user->date==date('Y-m-d')): ?>
                  Today
                  <?php elseif($user->date==date('Y-m-d',strtotime("-1 days"))): ?>
                  Yesterday
                  <?php else: ?>
                  <?php echo e(date('jS F Y', strtotime($user->date))); ?> - <?php echo e(date('h:i A', strtotime($user->date))); ?>

                  <?php endif; ?>
                </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                <td class="whitespace-nowrap px-4 py-3 sm:px-5">User Tracking Data not found !!</td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>






              </div>
          </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH /home/u442681501/domains/csmdevelopers.com/public_html/offercash_website/project/resources/views/admin/tracker.blade.php ENDPATH**/ ?>