
<?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
  <?php $BasicController = app('App\Http\Controllers\BasicController'); ?>
    <main class="main-content pos-app w-full px-[var(--margin-x)] pb-6 transition-all duration-[.25s]" >
      <div class="mt-3 col-12 container">
        <div class="col-span-12 sm:col-span-6 lg:col-span-8">
        <div class="mt-3 space-y-3.5">
           <!-- Missions Lists -->

         <?php if($missionsoffer->count() > 0): ?>
            <div class="flex items-center space-x-2" style="margin-top:20px; margin-bottom:-6px;">
            <img class="h-6 w-6" src="<?php echo e(url('images/icons/web-mis.png')); ?>">
            <div style="margin-left: 3px;">
            <span>Complate</span>
            <span class="text-xs uppercase text-slate-400 dark:text-navy-300">
            Offer Missions
            </span>
            </div>
            </div>
         <?php endif; ?>

         <div class="mi-grid">
           <?php echo e($qcheck = ""); ?>

           <?php $__currentLoopData = $missionsoffer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $moffer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <?php $qcheck = $BasicController::offerwall_check($moffer->m_id,$moffer->max_play); ?>
            <div class="card p-3 mi_card">
              <div class="mission-1">
              <div class="flex items-center space-x-3">
                <img
                  class="h-10 w-10 rounded-lg object-cover object-center"
                  src="<?php echo e(url('images/icons/web-mis.png')); ?>"
                  alt="image"
                />
                <div class="flex-1">
                  <div class="flex justify-between">
                    <p class="font-medium text-slate-700 dark:text-navy-100">
                    <?php echo e($moffer->m_title); ?>

                    </p>
                  </div>
                  <div class="mt-0.5 flex text-xs text-slate-400 dark:text-navy-300 line-clamp-1">
                     <p><?php echo e($moffer->m_title); ?>

                    <b class="text-xs text-red"> <?php echo e($moffer->points); ?> Coins</b></p>
                  </div>
                </div>
              </div>
               <div class="-mt-3 text-right text-xs font-medium text-white">
                <?php if($qcheck==0): ?>
                <?php echo e(Auth::user()->offer_play); ?>/<?php echo e($moffer->max_play); ?>

                <?php elseif($qcheck==1): ?>
                <form method="POST" action="">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="token_read" value="<?php echo e(Crypt::encryptString($moffer->m_id)); ?>"/>
                <input class="btn_2" type="submit" value="Collect"/>
                </form>
                <?php elseif($qcheck==2): ?>
                <button
                x-tooltip.placement.top.error="'Mission completed'"
                class="btn_2">
                <i class="fa-solid fa-check-double"></i>
                </button>
                <?php endif; ?>
                </div>
                </div>
                <p class="text-xs font-medium text-warning"></p>
               <div class="progress mt-2 h-1.5 bg-warning/15 dark:bg-warning/25">
              <progress value="<?php echo e(Auth::user()->offer_play); ?>" max="<?php echo e($moffer->max_play); ?>" class="w-7/12 rounded-full bg-warning"></progress>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>

          </div>

        </div>

      </div>
    </main>

   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php /**PATH /home/u442681501/domains/csmdevelopers.com/public_html/offercash_for_update/project/resources/views/missions.blade.php ENDPATH**/ ?>