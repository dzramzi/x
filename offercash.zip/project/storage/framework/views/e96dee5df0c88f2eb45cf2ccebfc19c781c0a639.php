<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AdminLayout::class, []); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <main class="main-content w-full px-[var(--margin-x)] pb-8">
      <div
        class="mt-4 grid grid-cols-1 gap-4 sm:mt-5 sm:gap-5 lg:mt-6 lg:gap-6"
      >
      <div class="col-span-12 lg:col-span-8">
        <?php if(session('status')): ?>
        <div class="alert flex rounded-lg bg-success px-4 py-4 text-white sm:px-5 mb-3 sess_msg">
        <?php echo e(session('status')); ?>

        </div>
        <?php endif; ?>
        <div class="card">
          <div class="flex flex-col items-center space-y-4 border-b border-slate-200 p-4 dark:border-navy-500 sm:flex-row sm:justify-between sm:space-y-0 sm:px-5">
            <h2 class="text-lg font-medium tracking-wide text-slate-700 dark:text-navy-100">
              Edit User
            </h2>
            <div class="flex justify-center space-x-2">
              <a href="<?php echo e(url('/admin/users')); ?>" class="btn min-w-[7rem] rounded-lg border border-slate-300 font-medium text-slate-700 hover:bg-slate-150 focus:bg-slate-150 active:bg-slate-150/80 dark:border-navy-450 dark:text-navy-100 dark:hover:bg-navy-500 dark:focus:bg-navy-500 dark:active:bg-navy-500/90">
                Cancel
              </a>
              <button class="btn min-w-[7rem] rounded-lg bg-primary font-medium text-white hover:bg-primary-focus focus:bg-primary-focus active:bg-primary-focus/90 dark:bg-accent dark:hover:bg-accent-focus dark:focus:bg-accent-focus dark:active:bg-accent/90"
              form="myform"
              type="submit">
              Save
              </button>
            </div>
          </div>
          <div class="p-4 sm:p-5">
            <div class="flex flex-col">
              <span class="text-base font-medium text-slate-600 dark:text-navy-100">Avatar</span>
              <div class="avatar mt-1.5 h-20 w-20">
                <img class="mask is-squircle" src="<?php echo e($user_data->picture); ?>" alt="avatar">
              </div>
            </div>
            <div class="my-7 h-px bg-slate-200 dark:bg-navy-500"></div>
            <form method="POST" action="" id="myform" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <label class="block">
                <span>Full Name </span>
                <span class="relative mt-1.5 flex">
                  <input class="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                  placeholder="Enter full name"
                  type="text"
                  name="name"
                  value="<?php echo e($user_data->name); ?>">
                  <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                    <i class="fa-regular fa-user text-base"></i>
                  </span>
                </span>
              </label>
              <label class="block">
                <span>Email Address </span>
                <span class="relative mt-1.5 flex">
                  <input class="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                  placeholder="Enter email address"
                  type="text"
                  name="email"
                  value="<?php echo e($user_data->email); ?>">
                  <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                    <i class="fa-regular fa-envelope text-base"></i>
                  </span>
                </span>
              </label>
              <label class="block">
                <span>Points </span>
                <span class="relative mt-1.5 flex">
                  <input class="form-input peer w-full rounded-lg border border-slate-300 bg-transparent px-3 py-2 pl-9 placeholder:text-slate-400/70 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:hover:border-navy-400 dark:focus:border-accent"
                  placeholder="Enter name"
                  type="text"
                  name="points"
                  value="<?php echo e($user_data->points); ?>">
                  <span class="pointer-events-none absolute flex h-full w-10 items-center justify-center text-slate-400 peer-focus:text-primary dark:text-navy-300 dark:peer-focus:text-accent">
                    <i class="fa-regular fa-user text-base"></i>
                  </span>
                </span>
              </label>
              <label class="block">
              <span>Status</span>
              <select name="status" class="form-select mt-1.5 w-full rounded-lg border border-slate-300 bg-layot-dark_csm px-3 py-2 hover:border-slate-400 focus:border-primary dark:border-navy-450 dark:bg-navy-700 dark:hover:border-navy-400 dark:focus:border-accent">
                <?php if($user_data->status==1): ?>
                <option value="1">Active</option>
                <option value="0">Deactivate</option>
                <?php else: ?>
                <option value="0">Deactivate</option>
                <option value="1">Active</option>
                <?php endif; ?>
              </select>
            </label>
            </div>
          </form>
            <div>
            </div>

          </div>
        </div>
      </div>

      </div>
    </main>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>
<?php /**PATH /home/u442681501/domains/csmdevelopers.com/public_html/offercash_for_update/project/resources/views/admin/edit_user.blade.php ENDPATH**/ ?>