<a {{ $attributes->merge(['class' => '']) }}>{{ $slot }}</a>
